package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Map;
import com.capgemini.fms.bean.Feedback;

public class FeedbackDAO implements IFeedbackDAO {

	Map<String,Integer> MathFeedbackMap = new HashMap<String,Integer>();
	Map<String,Integer> EnglishFeedbackMap = new HashMap<String,Integer>();
	Feedback feed = new Feedback();

	
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		
						
		if(subject.equalsIgnoreCase("math")) {
			MathFeedbackMap.put(name, rating);
			
				//add subject details
				if(MathFeedbackMap.containsKey(name)) {
					feed.setTopic(subject);
				}
			System.out.println("\nFeedback added");
			return MathFeedbackMap;
			
		}
		else if(subject.equalsIgnoreCase("english")){
			EnglishFeedbackMap.put(name, rating);
			
			//add subject details 
			if(EnglishFeedbackMap.containsKey(name)) {
				feed.setTopic(subject);
			}
			
			System.out.println("\nFeedback added");
			return EnglishFeedbackMap;
		}
		else {
			return null;
		}
		
	}

	@Override
	public Map<String, Integer> getFeedbackReports() {
		Map<String,Integer> map = new HashMap<String,Integer>();
		Map<String,Integer> resultMap = new HashMap<String,Integer>();

		try {
			
			System.out.println("\n*****English subject Feedback*****");
			for(String k : EnglishFeedbackMap.keySet()) {
				System.out.println("key("+k+"):value("+EnglishFeedbackMap.get(k)+")");
			}
			System.out.println("\n*****Math subject Feedback*****");
			for(String k : MathFeedbackMap.keySet()) {
				System.out.println("key("+k+"):value("+MathFeedbackMap.get(k)+")");
			}

			
			System.out.println("\nTeacher Name : Rating");
			map.putAll(EnglishFeedbackMap);
			map.putAll(MathFeedbackMap);
			
			for(String k : map.keySet()) {
				if(EnglishFeedbackMap.containsKey(k) && MathFeedbackMap.containsKey(k)){
					int engRate = EnglishFeedbackMap.get(k);
					int mathRate = MathFeedbackMap.get(k);
					
					if(engRate>mathRate) {
						resultMap.put(k, engRate);
					}
					else if(engRate<mathRate) {
						resultMap.put(k, mathRate);
					}
					else {
						resultMap.put(k, mathRate);
					}
				}
				else {
					int rate = map.get(k);
					resultMap.put(k, rate);
				}
			}

		
		}
		catch(NullPointerException exception) {
			System.out.println(exception.getMessage());	
		}
		return resultMap;		

	}
}
