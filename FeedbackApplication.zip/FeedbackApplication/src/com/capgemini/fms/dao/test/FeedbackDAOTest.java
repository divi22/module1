package com.capgemini.fms.dao.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.dao.FeedbackDAO;
import com.capgemini.fms.service.FeedbackService;

class FeedbackDAOTest {
	FeedbackDAO feedbackDao = new FeedbackDAO();
	FeedbackService fs  = new FeedbackService();
	Feedback feedback = new Feedback();

	@Test
	void test() {
		Map<String,Integer> testMap = new HashMap<String,Integer>();
		String tName = "Anisha";
		int rating = fs.checkRating(8);			//check rating :  rating value is between 1-5 
		String subject = fs.checkSubjectName("history");		//subject name should be english or math otherwise test will failed
		feedback.setTeacherName(tName);
		feedback.setRating(rating);
		feedback.setTopic(subject);
		testMap = feedbackDao.addFeedbackDetails(tName, rating, subject);
		for(String key : testMap.keySet()) {
			System.out.println(key + " - "+ testMap.get(key)+" - "+feedback.getTopic());
		}
	}	

}
