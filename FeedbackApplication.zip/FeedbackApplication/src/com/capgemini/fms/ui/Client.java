package com.capgemini.fms.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackService;


public class Client {
	static	FeedbackService service = new FeedbackService();
	public static void showMenu() {
		System.out.println("||------------------------|| DASHBOARD ||------------------------||");
		System.out.println("\n1) Add Feedback");
		System.out.println("2) Print Feedback Report");
		System.out.println("3) Exit");
		System.out.print("\nEnter Your Choice : ");
	}
	
	public static void main(String[] args) {
	Feedback feedback = new Feedback();
		Scanner scanner = new Scanner(System.in);
		int choice;
		while (true) {
			showMenu();
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("------------------------Add Feedback------------------------");
				System.out.print("Enter Teacher Name:");
				String tName = scanner.next();
				System.out.print("\nEnter Subject Name:");
				String subName = service.checkSubjectName(scanner.next());
				
				if(subName.equals("exit")) {   		// if service class return exit switch case will break.
		 			 break;
		 		}
				
				System.out.print("\nEnter Rating:");
				int rate = service.checkRating(scanner.nextInt());
				if(rate == 0) {   						// if service class return exit switch case will break.
		 			 break;
		 		}
				
				//add details of feedback
				feedback.setTeacherName(tName);
				feedback.setRating(rate);
				feedback.setTopic(subName);
				
				Map<String, Integer> details = service.addFeedbackDetails(tName, rate, subName);
				Set s = details.entrySet();
				Iterator i = s.iterator();
				while(i.hasNext())
				{
					System.out.println(i.next()+" "+feedback.getTopic());
				}
				
				break;
				
			case 2:
				System.out.println("------------------------Feedback Report------------------------");
				Map<String, Integer> feedbackReport = service.getFeedbackReport();
				
				for (String teacherName : feedbackReport.keySet()) {
					int rating = feedbackReport.get(teacherName);
					System.out.println(teacherName+"\t     : "+rating);
					
				}
				
				break;
			
			case 3:
				scanner.close();
				System.out.println("\n***Thank You***");
				System.exit(0);
				break;
				
			default:
		 		System.out.println("enter valid input");
				
			}
			
			
			
		}
		
	}

}
