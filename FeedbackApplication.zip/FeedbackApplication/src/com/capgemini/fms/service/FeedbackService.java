package com.capgemini.fms.service;

import java.util.Map;
import java.util.Scanner;

import com.capgemini.fms.dao.FeedbackDAO;

public class FeedbackService implements IFeedbackService{
	FeedbackDAO dao = new FeedbackDAO();
	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		return dao.addFeedbackDetails(name, rating, subject);
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return dao.getFeedbackReports();
	}

	//////////////////////////////////////////////////////////////////
	/////////////////////////// Validation ///////////////////////////
	//////////////////////////////////////////////////////////////////
	Scanner sc = new Scanner(System.in);
	public String checkSubjectName(String name) {
		while(true) {
			
			try {
				if(name.equalsIgnoreCase("math") || name.equalsIgnoreCase("english")) {
					return name;
				}
				else {
					
					throw new Exception();
				}
			}
			catch(Exception ex) {
				System.out.println("------------Input Error----------------");
				System.out.println("Please enter subject name as math/english");
				System.out.println("Enter subject name again:[Enter exit for dashboard]");
				name = sc.nextLine();
				if(name.equals("exit")) {
					return "exit";
				}
			}
		}
	}

	public int checkRating(int rate) {
		while(true) {
			
			try {
				if(rate <6 && rate>0) {
					return rate;
				}
				else {
					
					throw new Exception();
				}
			}
			catch(Exception ex) {
				System.out.println("------------Input Error----------------");
				System.out.println("Please enter rateing between 1 to 5");
				System.out.println("Enter rating again:[Enter 0 for dashboard]");
				rate = sc.nextInt();
				if(rate == 0) {
					return 0;
				}
			}
		}
	}

}
