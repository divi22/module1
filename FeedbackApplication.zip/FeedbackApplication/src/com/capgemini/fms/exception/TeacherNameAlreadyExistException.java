package com.capgemini.fms.exception;

public class TeacherNameAlreadyExistException extends Exception {
	
	public TeacherNameAlreadyExistException(String message) {
		super(message);
	}

}
